package com.example.deepa.myalertdialog;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn= (Button) findViewById(R.id.button);
    }

    public void showDialog(View view){
       // MyAlert myAlert=new MyAlert();
        //myAlert.show(getFragmentManager(),"My Alert");
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.icon);
        builder.setTitle("Confirm Delete...");
        builder.setMessage("Are You Sure You Want To Delete This ?");
        builder.setNegativeButton(R.string.No, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(),"No buttton was Clicked",Toast.LENGTH_LONG).show();
            }
        });

        builder.setPositiveButton(R.string.YES, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(),"Yes buttton was Clicked",Toast.LENGTH_LONG).show();
            }
        });





        Dialog dialog=builder.create();
        dialog.show();
    }
}
